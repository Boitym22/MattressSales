/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MattressSales1;


public class PrintProduct {
    private final Product product;
    
    public PrintProduct(Product product){
        this.product = product;
        
    }
     public void PrintTotalSales(){
         System.out.println("PRODUCT SALES REPORT - 2026");
          System.out.println("********************************************");
        System.out.println("TOTAL PRODUCT SALES: "
                + product.GetTotalProductsSold());
    }

    public void PrintAverageSales() {
        System.out.println("AVERAGE PRODUCT SALES: "
                + Math.round(product.GetAverageProductSold()));
    }

    public void PrintMostPopularProduct() {
        System.out.println("MOST POPULAR PRODUCT: "
                + product.GetMostPopularProduct());
    }
}
     

