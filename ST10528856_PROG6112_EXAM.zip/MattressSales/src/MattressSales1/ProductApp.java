/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MattressSales1;

import javax.swing.*;
import java.awt.*;
import java.io.FileWriter;
import java.io.IOException;

public class ProductApp extends JFrame {

    private final JTextField txtCustomerName;
    private final JTextField txtPrice;
    private final JComboBox<String> cmbProduct;
    private final JButton btnProcess;

    public ProductApp() {

        setTitle("Mattress Sales Application");
        setSize(500, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(4, 2, 10, 10));

        // Create the menu bar
        JMenuBar menuBar = new JMenuBar();

        JMenu fileMenu = new JMenu("File");
        JMenu toolsMenu = new JMenu("Tools");

        JMenuItem exitItem = new JMenuItem("Exit");
        JMenuItem processItem = new JMenuItem("Process");
        JMenuItem clearItem = new JMenuItem("Clear");

        fileMenu.add(exitItem);
        toolsMenu.add(processItem);
        toolsMenu.add(clearItem);

        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);

        setJMenuBar(menuBar);

        JLabel lblCustomer = new JLabel("Customer Name:");
        txtCustomerName = new JTextField();

        JLabel lblProduct = new JLabel("Product Name:");

        String[] products = {
            "Cozy Nights Monarch",
            "Restonic Barbados",
            "Sealy Phuket"
        };

        cmbProduct = new JComboBox<>(products);

        JLabel lblPrice = new JLabel("Product Price:");
        txtPrice = new JTextField();

        btnProcess = new JButton("PROCESS");

        add(lblCustomer);
        add(txtCustomerName);

        add(lblProduct);
        add(cmbProduct);

        add(lblPrice);
        add(txtPrice);

        add(new JLabel(""));
        add(btnProcess);

        btnProcess.addActionListener(e -> processSale());
        processItem.addActionListener(e -> processSale());

        clearItem.addActionListener(e -> clearFields());
        exitItem.addActionListener(e -> System.exit(0));

        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void processSale() {

        String customerName = txtCustomerName.getText().trim();
        String product = (String) cmbProduct.getSelectedItem();

        if (customerName.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Please enter the customer name.");
            return;
        }

        try {
            double price = Double.parseDouble(txtPrice.getText());

            if (price <= 0) {
                JOptionPane.showMessageDialog(this,
                        "Please enter a valid price.");
                return;
            }

            ProductCalculations calculations =
                    new ProductCalculations(price);

            double vat = calculations.GetVat();
            double commission = calculations.GetCommission();
            double total = calculations.GetTotal();

            // Save the sale details
            try (FileWriter writer = new FileWriter("data.txt", true)) {

                writer.write("DATA LOG\n");
                writer.write("Customer Name: " + customerName + "\n");
                writer.write("Product: " + product + "\n");
                writer.write("VAT: R " + vat + "\n");
                writer.write("COMMISSION: R " + commission + "\n");
                writer.write("TOTAL: R " + total + "\n\n");
            }

            JOptionPane.showMessageDialog(this,
                    "VAT: R " + vat
                    + "\nCOMMISSION: R " + commission
                    + "\nTOTAL: R " + total);

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this,
                    "Please enter a valid product price.");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this,
                    "Error saving data to file.");
        }
    }

    private void clearFields() {
        txtCustomerName.setText("");
        txtPrice.setText("");
        cmbProduct.setSelectedIndex(0);
    }

    public static void main(String[] args) {
        ProductApp productApp = new ProductApp();
    }
}


