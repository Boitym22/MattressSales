/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MattressSales1;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        try (Scanner input = new Scanner(System.in)) {
            String[] products = {
                "Cozy Nights Monarch",
                "Restonic Barbados",
                "Sealy Phuket"
            };
            
            int[][] sales = new int[3][3];
            
            // Get sales for each product over three months
            for (int i = 0; i < products.length; i++) {
                for (int j = 0; j < 3; j++) {
                    System.out.print("Enter number of sales for month "
                            + (j + 1) + " for " + products[i] + " mattress: ");
                    sales[i][j] = input.nextInt();
                }
                System.out.println();
            }

            Product product = new Product(products, sales) {
                @Override
                public double GetAverageProductsSold() {
                    throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
                }
            };
            PrintProduct report = new PrintProduct(product);
            
            report.PrintTotalSales();
            report.PrintAverageSales();
            report.PrintMostPopularProduct();
        }
    }
}
