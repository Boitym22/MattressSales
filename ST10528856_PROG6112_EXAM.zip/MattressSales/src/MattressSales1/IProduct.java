/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package MattressSales1;


public interface IProduct {
    int GetTotalProductsSold();
    double GetAverageProductsSold();
    String GetMostPopularProduct();
}
