/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MattressSales;

import MattressSales1.ProductCalculations;
import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class ProductCalculationsTest {

    @Test
    public void GetVat_WithValidData_ReturnsCorrectValue() {

        ProductCalculations calculations =
                new ProductCalculations(3500);

        assertEquals(525.0, calculations.GetVat(), 0.01);
    }

    @Test
    public void GetTotal_WithValidData_ReturnsCorrectValue() {

        ProductCalculations calculations =
                new ProductCalculations(3500);

        assertEquals(4200.0, calculations.GetTotal(), 0.01);
    }
}

